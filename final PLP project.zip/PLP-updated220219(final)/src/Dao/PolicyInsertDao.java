package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import Bean.AdminAccountBean;

public class PolicyInsertDao {
	AdminAccountBean accbean=new AdminAccountBean();
	Connection con=null;
	ResultSet resultSet = null;
	PreparedStatement pstmt = null;

	public int PolIns(int res,long acc) {
		//System.out.println(accbean.getAccNo());
		// TODO Auto-generated method stub
		try {
			con=DB.getConnection();
			String ins_str ="insert into policy values(pol_seq.NEXTVAL,?,?)";
			pstmt = con.prepareStatement(ins_str);
			  
			pstmt.setInt(1,res);
			pstmt.setLong(2,acc);
			
			
			int updateCount = pstmt.executeUpdate();
			  pstmt = con.prepareStatement("SELECT pol_seq.CURRVAL FROM DUAL");
				resultSet=pstmt.executeQuery();
			  
			  if(updateCount==1) {
			  if(resultSet.next())
				{
				  String pol=resultSet.getString(1);
				  return Integer.parseInt(pol);
							
				}
			  }
			  else {
				  System.out.println("insertion not done");
			  }
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	

}
