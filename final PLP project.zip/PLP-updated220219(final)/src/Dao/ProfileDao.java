package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import Bean.ProfileBean;

public class ProfileDao {

	public int addProfile(ProfileBean probean) {
		// TODO Auto-generated method stub
		Connection con = null;
		  PreparedStatement pstmt = null;
		  try {
			  
			  con=DB.getConnection(); 
			  
			  String ins_str ="insert into user_role values(?,?,?,'TRUE')";
			  
			  pstmt = con.prepareStatement(ins_str);
			  
			  pstmt.setString(1,probean.getUser());
			  pstmt.setString(2,probean.getPass());
			  pstmt.setString(3,probean.getRole());
			  
			  
			  int updateCount = pstmt.executeUpdate();
			  
			  con.close();
			  
			  return updateCount;
		  }catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
	}

}
