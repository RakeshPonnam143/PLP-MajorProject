package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.DB;
import Service.AgentPremiumCalService;

public class AgentCalController extends HttpServlet{
	Connection con = null;
	PreparedStatement pst=null;
	Statement statement = null;
	ResultSet resultSet = null;
	//List<String> al=new ArrayList<>();
	HashMap<String,String> ans=new HashMap<String,String>();
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		long acc=Long.parseLong(request.getParameter("accno"));
		String agentname=request.getParameter("agentname");
		PrintWriter out=response.getWriter();
		AgentPremiumCalService premium=new AgentPremiumCalService();
		try {
			con=DB.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			statement=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql ="select Pol_Ques_Desc,Pol_ques_id from policy_questions p,business_segment b where (p. BUS_SEG_ID=b. BUS_SEG_ID)";
		try {
			
			resultSet = statement.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String Ans1="";
		String Ans2="";
		
		try {
			while(resultSet.next()){
				Ans2=resultSet.getString(1);
				Ans1=request.getParameter(Ans2);
				ans.put(Ans2,Ans1);
				}
			/*for(Map.Entry<String, String> m:ans.entrySet())
			{
				System.out.println(m.getKey()+"  "+m.getValue());
			}*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int policynumber=premium.CalculatePremium(ans,acc);
		
		//out.print("Policy Number is"+policynumber);
		String str="update agent_details set pol_no="+policynumber+" where acc_no="+acc+"";
		try {
			pst=con.prepareStatement(str);
			pst.executeUpdate(str);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int ab=premium.Inspol(policynumber,ans);
		System.out.println(ab);
		
		//out.println("<a href=\"Login.jsp\">Return to Home page</a>");
		
		out.print("<html><style> .bg-img {\r\n" + 
				"  /* The image used */\r\n" + 
				"  background-image: url(\"policynumber.jpg\");\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"  width:1415px;\r\n" + 
				"  height:780px;\r\n" + 
				"\r\n" + 
				"  /* Center and scale the image nicely */\r\n" + 
				"  background-position: center;\r\n" + 
				"  background-repeat: no-repeat;\r\n" + 
				"  background-size: cover;\r\n" + 
				"  position: relative;\r\n" + 
				"} </style><body><div class=\"bg-img\"> "
				+ " <b>Policy Number is </b>" +policynumber +" <br><br><br> <a href='agent.jsp'>  Return to home page </a></div></body></html>");

			}
	
}
