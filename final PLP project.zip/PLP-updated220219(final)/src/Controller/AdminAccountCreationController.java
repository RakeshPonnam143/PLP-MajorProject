package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Service.AccountCreationService;
import Service.ProfileCreationService;

public class AdminAccountCreationController extends HttpServlet{
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		RequestDispatcher rd = null;
		String name="";
		String street="";
		String city="";
		String state="";
		int zip=0;
		String business="";
		String uname="";
		
		name=request.getParameter("insured");
		street=request.getParameter("street");
		city=request.getParameter("city");
		state=request.getParameter("state");
		
		String pin=request.getParameter("pincode");
		zip=Integer.parseInt(pin);
		
		business=request.getParameter("business");
		uname=request.getParameter("uname");
		
		long Accseq = AccountCreationService.addAccountService(name, street, city,state,zip,business,uname);
		out.print("Account Number is"+Accseq);
		out.println("<br><br><a href='admin.jsp'>Policy Creation</a>");
		//System.out.println("Account Number is"+Accseq);
		
		/*if (Accseq>0) {
			rd = request.getRequestDispatcher("/PolicyCreation.jsp");
			
		} else {
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
			}*/

			}}
